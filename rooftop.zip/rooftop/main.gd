extends Node2D

var score := 0
var ended := false

@onready var score_label = $CanvasLayer/ScoreLabel
@onready var score_timer = $ScoreTimer

func _ready():
	score_timer.timeout.connect(_on_score_timer_timeout) # ✅ ensure connected
	_update_score()

func _on_score_timer_timeout():
	if ended:
		return
	score += 1
	_update_score()

func _update_score():
	score_label.text = "Score: " + str(score)

func _on_death_zone_body_entered(body: Node2D):
	if body.name == "Player":
		ended = true
		score_timer.stop()   # ✅ stop score when dead
		get_tree().reload_current_scene()
