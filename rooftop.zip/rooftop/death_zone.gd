extends Area2D

# Connect the DeathZone's "body_entered" signal to this script!
func _on_body_entered(body):
	if body.name == "Player":
		# Restart the level instantly
		get_tree().reload_current_scene()
