extends CharacterBody2D

const SPEED = 250.0
const JUMP_VELOCITY = -500.0
var gravity = 980.0

func _physics_process(delta):
	# 1. Apply gravity
	if not is_on_floor():
		velocity.y += gravity * delta

	# 2. Jump (ui_up is the Up Arrow or W key. ui_accept is Spacebar)
	if Input.is_action_just_pressed("ui_up") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# 3. Manual Left/Right Movement
	var direction = Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = 0 # Stop moving when you let go of the keys

	move_and_slide()
