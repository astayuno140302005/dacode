extends Node2D

@onready var treasure_label = $CanvasLayer/TreasureLabel
@onready var oxygen_label = $CanvasLayer/OxygenLabel
@onready var game_over_label = $CanvasLayer/GameOverLabel
@onready var oxygen_timer = $OxygenTimer
@onready var player = $Player

var treasure := 0
var oxygen := 20
var ended := false

func _ready():
	game_over_label.visible = false
	oxygen_timer.timeout.connect(_on_oxygen_timer_timeout)

	for coin in get_tree().get_nodes_in_group("coins"):
		coin.collected.connect(_on_coin_collected)

	_update_ui()

func _on_coin_collected():
	if ended:
		return

	treasure += 1
	_update_ui()

	# wait one frame so coin is actually removed
	await get_tree().process_frame

	if get_tree().get_nodes_in_group("coins").size() == 0:
		_game_over()

func _on_oxygen_timer_timeout():
	if ended:
		return

	oxygen -= 1
	_update_ui()

	if oxygen <= 0:
		_game_over()

func _game_over():
	if ended:
		return

	ended = true
	oxygen_timer.stop()
	game_over_label.visible = true
	player.game_over()

	await get_tree().create_timer(1.0).timeout
	get_tree().reload_current_scene()

func _update_ui():
	treasure_label.text = "Treasure: %d" % treasure
	oxygen_label.text = "Oxygen: %d" % oxygen
