extends CharacterBody2D

@export var speed := 220.0
var alive := true

func _physics_process(delta):
	if not alive:
		return

	var dir = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = dir * speed
	move_and_slide()

	var s = get_viewport_rect().size
	global_position.x = clamp(global_position.x, 20, s.x - 20)
	global_position.y = clamp(global_position.y, 20, s.y - 20)

func game_over():
	alive = false
	velocity = Vector2.ZERO
