extends Area2D

signal scored
signal hit_player

@export var speed := 240.0
var screen_h := 0.0

func _ready():
	add_to_group("coconut")
	body_entered.connect(_on_body_entered)
	screen_h = get_viewport_rect().size.y

func _process(delta):
	position.y += speed * delta

	if position.y > screen_h + 40:
		scored.emit()
		queue_free()

func _on_body_entered(body):
	if body.is_in_group("ground"):
		scored.emit()
		queue_free()
	elif body.is_in_group("player"):
		hit_player.emit()
		queue_free()
