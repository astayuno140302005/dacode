extends Node2D

@onready var score_label: Label = $CanvasLayer/ScoreLabel
@onready var game_over_label: Label = $CanvasLayer/GameOver
@onready var spawn_timer: Timer = $SpawnTimer
@onready var coconut_scene := preload("res://Coconut.tscn")
@onready var player := $player

var score := 0
var ended := false

func _ready():
	randomize()
	game_over_label.visible = false
	_update_score()

func _on_spawn_timer_timeout():
	if ended:
		return

	var coconut = coconut_scene.instantiate()
	add_child(coconut)

	var w := get_viewport_rect().size.x
	coconut.global_position = Vector2(randf_range(20, w - 20), -30)

	coconut.scored.connect(_on_coconut_scored)
	coconut.hit_player.connect(_on_game_over)

func _on_coconut_scored():
	if ended:
		return
	score += 1
	_update_score()

func _on_game_over():
	if ended:
		return

	ended = true
	spawn_timer.stop()
	player.game_over()

	# 🔴 stop all existing coconuts immediately
	for c in get_tree().get_nodes_in_group("coconut"):
		c.queue_free()

	game_over_label.text = "Game Over"
	game_over_label.visible = true

func _update_score():
	score_label.text = "Score: %d" % score
