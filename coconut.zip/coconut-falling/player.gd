extends CharacterBody2D

@export var speed := 350.0
var dead := false

func _physics_process(delta):
	if dead:
		return

	var dir := Input.get_axis("ui_left", "ui_right")
	velocity.x = dir * speed
	velocity.y = 0
	move_and_slide()

	var w := get_viewport_rect().size.x
	global_position.x = clamp(global_position.x, 20, w - 20)

func game_over():
	dead = true
