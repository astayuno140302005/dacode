extends Area2D

@export var target: Node2D

func _physics_process(delta):
	if target:
		look_at(target.global_position)
		# Move toward player without complex physics
		position = position.move_toward(target.global_position, 100 * delta)

# Connect the "body_entered" signal of this Area2D to this script!
func _on_body_entered(body):
	if body.name == "Player":
		get_tree().reload_current_scene() # Game Over / Restart
