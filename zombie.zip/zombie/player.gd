extends CharacterBody2D

func _physics_process(_delta):
	# Gets standard arrow key / WASD movement automatically
	var direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = direction * 200.0
	move_and_slide()
